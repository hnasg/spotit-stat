// ===== charts.js =====
// Graphiques de la page "musique d'hina" (Chart.js)

// ---- Top 10 des artistes (barres horizontales) ----
new Chart(document.getElementById("chartArtistes"), {
  type: "bar",
  data: {
    labels: [
      "Ado", "SCANDAL", "zarame", "HepuPiano", "Superfly",
      "TRUE", "茅原実里", "Yorushika", "NEK!", "Tao Tsuchiya"
    ],
    datasets: [{
      data: [7, 4, 3, 2, 2, 1, 1, 1, 1, 1],
      backgroundColor: "#9ec5e8",
      borderColor: "#7fb0dd",
      borderWidth: 1
    }]
  },
  options: {
    indexAxis: "y",
    responsive: true,
    aspectRatio: 1.4,
    plugins: {
      legend: { display: false }
    },
    scales: {
      x: {
        beginAtZero: true,
        ticks: { stepSize: 1 },
        title: { display: true, text: "Nombre de morceaux" }
      }
    }
  }
});

// ---- Distribution des genres (camembert) ----
new Chart(document.getElementById("chartGenres"), {
  type: "pie",
  data: {
    labels: [
      "animé", "j-pop", "j-rock", "vocaloid",
      "indie japonaise", "variété française", "chanson", "Autres"
    ],
    datasets: [{
      data: [30, 25, 18, 8, 6, 5, 4, 4],
      backgroundColor: [
        "#f48fa0", // animé
        "#6fb3e0", // j-pop
        "#f4d06b", // j-rock
        "#7cc7bb", // vocaloid
        "#b39ddb", // indie japonaise
        "#f3a45c", // variété française
        "#82c785", // chanson
        "#bdbdbd"  // Autres
      ]
    }]
  },
  options: {
    responsive: true,
    aspectRatio: 1.4,
    plugins: {
      legend: {
        position: "right",
        labels: { boxWidth: 14, font: { size: 11 } }
      }
    }
  }
});
